package Presentacion.FactoriaGUI;

public interface ObservadorGUI {
	public void actualizar(int evento, Object datos);
}
